
import React, { useState, useEffect } from 'react';
import { ZodiacSign } from '../types';
import { getDailyHoroscope } from '../services/geminiService';

interface Props {
  sign: ZodiacSign;
  onBack: () => void;
}

const ZodiacDetail: React.FC<Props> = ({ sign, onBack }) => {
  const [horoscope, setHoroscope] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchHoroscope();
    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [sign]);

  const fetchHoroscope = async () => {
    setLoading(true);
    const text = await getDailyHoroscope(sign.name);
    setHoroscope(text);
    setLoading(false);
  };

  const getVibeClass = () => {
    switch (sign.element) {
      case 'Гал': return 'vibe-flame ring-red-500/20';
      case 'Ус': return 'vibe-wave ring-blue-500/20';
      case 'Хий': return 'vibe-air ring-purple-500/20';
      case 'Шороо': return 'vibe-earth ring-green-500/20';
      default: return '';
    }
  };

  return (
    <div className="animate-fade-in-up pb-20">
      <button 
        onClick={onBack}
        className="mb-8 flex items-center gap-2 text-white/60 hover:text-white transition-colors"
      >
        <span>←</span> Буцах
      </button>

      <div className={`p-8 md:p-12 rounded-[2.5rem] bg-white/5 border border-white/10 backdrop-blur-xl relative overflow-hidden ring-4 ${getVibeClass()}`}>
        {/* Decorative Element Icon */}
        <div className="absolute -top-10 -right-10 text-[15rem] opacity-5 pointer-events-none select-none">
          {sign.symbol}
        </div>

        <div className="flex flex-col md:flex-row gap-12 items-center md:items-start relative z-10">
          <div className="text-center md:text-left">
            <div className="text-8xl md:text-[10rem] mb-4 animate-float drop-shadow-2xl">
              {sign.symbol}
            </div>
            <h2 className="text-5xl md:text-7xl font-bold mb-2 tracking-tighter">{sign.name}</h2>
            <p className="text-xl text-yellow-400 font-medium">{sign.dates} • {sign.element}</p>
          </div>

          <div className="flex-1 space-y-8">
            <section>
              <h3 className="text-2xl font-bold mb-4 flex items-center gap-2">
                <span className="w-8 h-px bg-white/20"></span> Ерөнхий төлөв
              </h3>
              <p className="text-lg text-white/80 leading-relaxed">{sign.description}</p>
            </section>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white/5 p-6 rounded-2xl border border-white/5">
                <h4 className="font-bold text-green-400 mb-3 flex items-center gap-2">💪 Давуу тал</h4>
                <ul className="space-y-2 text-white/70">
                  {sign.strengths.map(s => <li key={s}>• {s}</li>)}
                </ul>
              </div>
              <div className="bg-white/5 p-6 rounded-2xl border border-white/5">
                <h4 className="font-bold text-red-400 mb-3 flex items-center gap-2">⚠️ Сул тал</h4>
                <ul className="space-y-2 text-white/70">
                  {sign.weaknesses.map(w => <li key={w}>• {w}</li>)}
                </ul>
              </div>
            </div>

            <div className="space-y-6">
              <section className="bg-pink-500/5 border border-pink-500/10 p-6 rounded-2xl">
                <h4 className="font-bold text-pink-400 mb-2">❤️ Хайр дурлал</h4>
                <p className="text-white/80">{sign.love}</p>
              </section>
              <section className="bg-blue-500/5 border border-blue-500/10 p-6 rounded-2xl">
                <h4 className="font-bold text-blue-400 mb-2">💼 Ажил & Карьер</h4>
                <p className="text-white/80">{sign.career}</p>
              </section>
              <section className="bg-yellow-500/5 border border-yellow-500/10 p-6 rounded-2xl">
                <h4 className="font-bold text-yellow-400 mb-2">🤝 Тохирох ордууд</h4>
                <div className="flex gap-2 flex-wrap">
                  {sign.compatibility.map(c => (
                    <span key={c} className="px-3 py-1 bg-white/10 rounded-full text-sm font-medium">{c}</span>
                  ))}
                </div>
              </section>
            </div>

            {/* Mongolian Twist */}
            <div className="mt-12 p-8 bg-gradient-to-br from-indigo-500/20 to-purple-500/20 rounded-3xl border border-white/10 relative overflow-hidden group">
              <div className="absolute top-0 left-0 w-2 h-full bg-yellow-400"></div>
              <h3 className="text-2xl font-bold mb-4 flex items-center gap-3">
                🇲🇳 Монгол зан чанар
              </h3>
              <p className="text-xl italic text-white/90 leading-relaxed font-serif">
                {sign.mongolianTwist}
              </p>
            </div>

            {/* Daily Horoscope from Gemini */}
            <div className="mt-8 p-8 bg-black/40 rounded-3xl border border-white/5 backdrop-blur-sm">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-2xl font-bold text-yellow-400">Өнөөдрийн мессеж 🔮</h3>
                <button 
                  onClick={fetchHoroscope}
                  className="text-xs text-white/40 hover:text-white transition-colors uppercase tracking-widest"
                >
                  Шинэчлэх
                </button>
              </div>
              {loading ? (
                <div className="flex flex-col items-center py-10 gap-4">
                  <div className="w-12 h-12 border-4 border-yellow-400 border-t-transparent rounded-full animate-spin"></div>
                  <p className="text-white/60 animate-pulse">Одод таны төлөө шивнэж байна...</p>
                </div>
              ) : (
                <div className="prose prose-invert max-w-none">
                  <p className="text-white/80 whitespace-pre-line text-lg leading-relaxed">
                    {horoscope || "Зурхайг ачаалахад алдаа гарлаа. Дахин оролдоно уу."}
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ZodiacDetail;
