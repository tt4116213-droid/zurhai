
import React, { useState } from 'react';
import { ZodiacSign } from '../types';

interface Props {
  onBack: () => void;
  signs: ZodiacSign[];
}

const Compatibility: React.FC<Props> = ({ onBack, signs }) => {
  const [signA, setSignA] = useState<ZodiacSign | null>(null);
  const [signB, setSignB] = useState<ZodiacSign | null>(null);
  const [calculating, setCalculating] = useState(false);
  const [result, setResult] = useState<number | null>(null);

  const handleCalculate = () => {
    if (!signA || !signB) return;
    setCalculating(true);
    setResult(null);
    
    // Fake calculation delay
    setTimeout(() => {
      // Logic: Same element = higher, Opposites = medium, Random base
      let score = 50 + Math.floor(Math.random() * 30);
      if (signA.element === signB.element) score += 15;
      if (signA.id === signB.id) score -= 10;
      setResult(Math.min(score, 100));
      setCalculating(false);
    }, 1500);
  };

  return (
    <div className="max-w-4xl mx-auto py-10 px-4">
      <button onClick={onBack} className="mb-8 text-white/60 hover:text-white">← Буцах</button>

      <div className="bg-white/5 p-8 md:p-12 rounded-[2rem] border border-white/10 text-center">
        <h2 className="text-4xl font-bold mb-12">❤️ Ордны тохироо шалгагч</h2>
        
        <div className="flex flex-col md:flex-row items-center justify-center gap-8 mb-12">
          {/* Sign A Selector */}
          <div className="flex flex-col items-center">
            <div className={`w-32 h-32 md:w-40 md:h-40 rounded-full border-2 ${signA ? 'border-yellow-400 bg-yellow-400/10' : 'border-white/10 bg-white/5'} flex items-center justify-center text-6xl transition-all`}>
              {signA ? signA.symbol : '?'}
            </div>
            <select 
              className="mt-4 bg-transparent border-b border-white/20 p-2 outline-none text-center"
              onChange={(e) => setSignA(signs.find(s => s.id === e.target.value) || null)}
              value={signA?.id || ''}
            >
              <option value="" disabled className="bg-slate-900">Миний орд</option>
              {signs.map(s => <option key={s.id} value={s.id} className="bg-slate-900">{s.name}</option>)}
            </select>
          </div>

          <div className="text-4xl text-white/20 font-bold">VS</div>

          {/* Sign B Selector */}
          <div className="flex flex-col items-center">
            <div className={`w-32 h-32 md:w-40 md:h-40 rounded-full border-2 ${signB ? 'border-pink-500 bg-pink-500/10' : 'border-white/10 bg-white/5'} flex items-center justify-center text-6xl transition-all`}>
              {signB ? signB.symbol : '?'}
            </div>
            <select 
              className="mt-4 bg-transparent border-b border-white/20 p-2 outline-none text-center"
              onChange={(e) => setSignB(signs.find(s => s.id === e.target.value) || null)}
              value={signB?.id || ''}
            >
              <option value="" disabled className="bg-slate-900">Түүний орд</option>
              {signs.map(s => <option key={s.id} value={s.id} className="bg-slate-900">{s.name}</option>)}
            </select>
          </div>
        </div>

        {signA && signB && !calculating && !result && (
          <button 
            onClick={handleCalculate}
            className="px-12 py-5 bg-white text-black font-bold rounded-full hover:bg-yellow-400 transition-colors text-xl"
          >
            Тооцоолох
          </button>
        )}

        {calculating && (
          <div className="flex flex-col items-center gap-4 py-8">
            <div className="w-16 h-16 border-4 border-pink-500 border-t-transparent rounded-full animate-spin"></div>
            <p className="text-xl animate-pulse">Зүрхний цохилтыг хэмжиж байна...</p>
          </div>
        )}

        {result && (
          <div className="animate-fade-in-up">
            <div className="text-8xl font-black text-pink-500 mb-4">{result}%</div>
            <h3 className="text-2xl font-bold mb-4">
              {result > 80 ? "Төгс хосууд! 💍" : result > 50 ? "Маш сайн тохироо 💖" : "Бага зэрэг хичээх хэрэгтэй 😊"}
            </h3>
            <p className="text-white/60 max-w-lg mx-auto mb-10">
              {signA.name} болон {signB.name} ордныхон бол {signA.element} болон {signB.element} элементийн хослол юм. Энэ нь {result > 70 ? "байгалийн тогтоц шиг зохицолтой" : "өвөрмөц бөгөөд сонирхолтой"} харилцааг бий болгодог.
            </p>
            <button 
              onClick={() => {setResult(null); setSignA(null); setSignB(null);}}
              className="text-white/40 underline hover:text-white"
            >
              Дахин шалгах
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Compatibility;
