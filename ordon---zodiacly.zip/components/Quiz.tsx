
import React, { useState } from 'react';
import { QUIZ_QUESTIONS, ZODIAC_SIGNS } from '../constants';
import { ZodiacSign } from '../types';

interface Props {
  onBack: () => void;
  signs: ZodiacSign[];
}

const Quiz: React.FC<Props> = ({ onBack, signs }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [totalScore, setTotalScore] = useState(0);
  const [showResult, setShowResult] = useState(false);

  const handleAnswer = (value: number) => {
    setTotalScore(prev => prev + value);
    if (currentStep < QUIZ_QUESTIONS.length - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      setShowResult(true);
    }
  };

  const calculateResult = () => {
    // Mock logic to determine "match"
    // In a real app, this would be more complex
    const percentage = Math.min(Math.round((totalScore / 50) * 100), 100);
    // Find closest sign based on some logic (random for demo or based on element)
    const randomSign = signs[Math.floor(Math.random() * signs.length)];
    return { percentage, sign: randomSign };
  };

  const result = calculateResult();

  return (
    <div className="max-w-2xl mx-auto py-10 px-4">
      <button onClick={onBack} className="mb-8 text-white/60 hover:text-white">← Буцах</button>

      {!showResult ? (
        <div className="bg-white/5 p-8 md:p-12 rounded-[2rem] border border-white/10 text-center animate-fade-in">
          <div className="w-full bg-white/10 h-2 rounded-full mb-10 overflow-hidden">
            <div 
              className="bg-yellow-400 h-full transition-all duration-500" 
              style={{ width: `${((currentStep + 1) / QUIZ_QUESTIONS.length) * 100}%` }}
            ></div>
          </div>
          
          <h2 className="text-3xl font-bold mb-10">{QUIZ_QUESTIONS[currentStep].question}</h2>
          
          <div className="grid grid-cols-1 gap-4">
            {QUIZ_QUESTIONS[currentStep].options.map((opt, idx) => (
              <button
                key={idx}
                onClick={() => handleAnswer(opt.value)}
                className="p-5 rounded-2xl bg-white/5 border border-white/10 hover:bg-yellow-400 hover:text-black transition-all text-left text-lg font-medium"
              >
                {opt.text}
              </button>
            ))}
          </div>
        </div>
      ) : (
        <div className="bg-white/5 p-8 md:p-12 rounded-[2rem] border border-white/10 text-center animate-bounce-in">
          <h2 className="text-2xl font-bold text-white/60 mb-4 uppercase tracking-widest">Таны үр дүн</h2>
          <div className="text-[10rem] mb-4 animate-float">{result.sign.symbol}</div>
          <div className="text-7xl font-bold text-yellow-400 mb-2">{result.sign.name} — {result.percentage}%</div>
          <p className="text-xl text-white/80 max-w-md mx-auto mb-10">
            “Чиний зан чанар {result.sign.name} ордтой маш ойр байна. {result.sign.description}”
          </p>
          <button 
            onClick={onBack}
            className="px-10 py-4 bg-yellow-400 text-black font-bold rounded-full hover:scale-105 transition-transform"
          >
            Дахин эхлэх
          </button>
        </div>
      )}
    </div>
  );
};

export default Quiz;
