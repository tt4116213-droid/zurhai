
import React, { useState } from 'react';
import { MoodType } from '../types';

const MoodAdvice: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  const [selectedMood, setSelectedMood] = useState<MoodType | null>(null);

  const moods: { type: MoodType; emoji: string; color: string; advice: string }[] = [
    { 
      type: 'Жаргалтай', 
      emoji: '🌟', 
      color: 'bg-yellow-400', 
      advice: 'Энэхүү эерэг энергиэ бусадтай хуваалцаарай. Өнөөдөр таны хувьд шинэ боломжуудын хаалга нээлттэй байна.' 
    },
    { 
      type: 'Гунигтай', 
      emoji: '🌙', 
      color: 'bg-blue-400', 
      advice: 'Гуниг бол түр зуурынх. Өөртөө амралт өгч, дуртай хөгжмөө сонсоорой. Одод таныг хамгаалж байна.' 
    },
    { 
      type: 'Ууртай', 
      emoji: '🔥', 
      color: 'bg-red-500', 
      advice: 'Гүнзгий амьсгаа ав. Уур бол шатаж дуусдаг гал юм. Тайвшраад асуудлыг өөр өнцгөөс хараарай.' 
    },
    { 
      type: 'Ядарсан', 
      emoji: '💤', 
      color: 'bg-indigo-400', 
      advice: 'Бие махбодоо сонс. Халуун цай ууж, эрт унтаж амраарай. Маргааш шинэ эрч хүчээр дүүрэн сэрэх болно.' 
    },
    { 
      type: 'Түгшүүртэй', 
      emoji: '🌊', 
      color: 'bg-teal-400', 
      advice: 'Бүх зүйл таны хяналтанд байх албагүй. Одоо байгаа цаг мөчдөө анхаарлаа хандуул. Та аюулгүй байна.' 
    },
  ];

  return (
    <div className="max-w-4xl mx-auto py-10 px-4">
      <button onClick={onBack} className="mb-8 text-white/60 hover:text-white">← Буцах</button>

      <div className="bg-white/5 p-8 md:p-12 rounded-[2rem] border border-white/10 text-center">
        <h2 className="text-4xl font-bold mb-4">Одоогийн сэтгэл санаа?</h2>
        <p className="text-white/60 mb-12">Таны дотоод ертөнц өнөөдөр ямар байна вэ?</p>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-12">
          {moods.map(m => (
            <button
              key={m.type}
              onClick={() => setSelectedMood(m.type)}
              className={`p-6 rounded-2xl border ${selectedMood === m.type ? 'border-yellow-400 bg-white/10 scale-105' : 'border-white/5 bg-white/5'} hover:border-white/20 transition-all flex flex-col items-center gap-2`}
            >
              <span className="text-4xl">{m.emoji}</span>
              <span className="text-xs font-bold uppercase">{m.type}</span>
            </button>
          ))}
        </div>

        {selectedMood && (
          <div className="animate-fade-in-up p-8 bg-white/5 border border-white/10 rounded-3xl">
            <h3 className="text-2xl font-bold mb-4 text-yellow-400">Оддын зөвлөгөө ✨</h3>
            <p className="text-xl italic leading-relaxed text-white/90">
              "{moods.find(m => m.type === selectedMood)?.advice}"
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default MoodAdvice;
