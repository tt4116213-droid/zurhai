
import React from 'react';
import { ZodiacSign } from '../types';

interface Props {
  signs: ZodiacSign[];
  onSelect: (sign: ZodiacSign) => void;
}

const ZodiacGrid: React.FC<Props> = ({ signs, onSelect }) => {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-6">
      {signs.map((sign) => (
        <div
          key={sign.id}
          onClick={() => onSelect(sign)}
          className={`relative overflow-hidden p-6 rounded-2xl border border-white/10 bg-white/5 hover:bg-white/10 hover:border-yellow-400/50 cursor-pointer transition-all group flex flex-col items-center justify-center transform hover:-translate-y-2`}
        >
          {/* Subtle Glow */}
          <div className={`absolute -inset-1 opacity-0 group-hover:opacity-20 blur-xl transition-opacity ${sign.color}`}></div>
          
          <div className="text-5xl mb-4 group-hover:scale-125 transition-transform duration-500">
            {sign.symbol}
          </div>
          <h3 className="text-xl font-bold tracking-wider">{sign.name}</h3>
          <p className="text-xs opacity-60 mt-1">{sign.dates}</p>
          <div className="mt-2 text-[10px] px-2 py-0.5 rounded-full bg-white/10 uppercase tracking-tighter opacity-80">
            {sign.element}
          </div>
        </div>
      ))}
    </div>
  );
};

export default ZodiacGrid;
